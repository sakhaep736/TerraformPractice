def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Lambda executed successfully from ZIP in S3!"
    }
}
